Text to Quiz Generator (GPT API Proxy)

How to Set Up:
1. Make sure you have Python 3 installed.
2. Navigate to the project directory in your terminal.
3. Create a virtual environment (optional but recommended):
   python3 -m venv venv
   source venv/bin/activate

4. Install dependencies:
   pip install -r requirements.txt

5. Set your OpenAI API key as an environment variable:
   export OPENAI_API_KEY='your-api-key-here'

6. Run the app:
   python app.py

7. Visit http://localhost:5000 in your browser.